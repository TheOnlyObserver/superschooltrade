// pages/communicatePage/communicatePage.js
var id, session
var tempFilePathsShow = new Array;
var title, content, price; //标题内容，正文内容，价格
var ifnewpercent = 100;
var classification1 = 1; //四大分类
var classification2 = 1; //二级分类
var classification3 = 1; //三级分类
var classification23 //二三级分类合并
var multiarray; //多列选择器数组
var imgurl = new Array;
var k = 0;
var app = getApp()
var imgViewList = new Array;
var towidth = new Array;
var toheight = new Array;
var oldwidth = new Array;
var oldheight = new Array;

//价格格式限制函数
function money(val) {
  let num = val.toString(); //先转换成字符串类型
  if (num.indexOf('.') == 0) { //第一位就是 .
    num = '0' + num
  }
  num = num.replace(/[^\d.]/g, ""); //清除“数字”和“.”以外的字符
  num = num.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
  num = num.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
  num = num.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //只能输入两个小数
  if (num.indexOf(".") < 0 && num != "") {
    num = parseFloat(num);
  }
  return num
}

function convert(a, b) {
  return ([, [Number(("" + arguments[0]).slice(0, 3).replace(/1/, "")), Number(("" + arguments[0]).slice(3))], Number("1" + (arguments[0] / Math.pow(10, 2)).toFixed(2).substr(2) + arguments[1])])[arguments.length]
}

//地狱回调函数，获取图片信息
function infernal(aa) {
  var that = aa
  imgViewList = []
  towidth = []
  toheight = []
  oldwidth = []
  oldheight = []
  wx.chooseImage({
    count: 4,
    sizeType: ['compressed'],
    sourceType: ['album', 'camera'],
    success: function(photo) {
      var j = 0
      var tmpDataArr = new Array;
      var w = 1
      var imgInfo = 0
      console.log('图片数量', photo.tempFilePaths.length)
      if (photo.tempFilePaths == undefined) {
        wx.navigateBack({
          delta: 1,
        })
      }
      //回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱回调地狱
      wx.getImageInfo({
        src: photo.tempFilePaths[j],
        success: function(res) { //1
          console.log('res', res)
          console.log('第', j, '高', res.height)
          console.log('第', j, '宽', res.width)
          towidth[j] = 500; //按比例压缩
          toheight[j] = Math.trunc(500 * res.height / res.width);
          oldwidth[j] = res.width
          oldheight[j] = res.height
          console.log('第', j, '高', toheight)
          console.log('第', j, '宽', towidth)
          console.log('toheight', toheight)
          j++

          if (j == photo.tempFilePaths.length) {
            console.log('tmpDataArr ', tmpDataArr)
            tempFilePathsShow = photo.tempFilePaths //这个是选择后返回的图片列表
            console.log('tempFilePathsShow', tempFilePathsShow, 'towidth', towidth, 'toheight', toheight)
            console.log('toheight', toheight)
            that.getCanvasImg(0, 0, tempFilePathsShow, oldwidth, oldheight, towidth, toheight); //进行压缩
            that.setData({
              tempfilepaths: tempFilePathsShow
            })
          }
          wx.getImageInfo({
            src: photo.tempFilePaths[j],
            success: function(res) { //2
              console.log('res', res)
              console.log('第', j, '高', res.height)
              console.log('第', j, '宽', res.width)
              towidth[j] = 500; //按比例压缩
              toheight[j] = Math.trunc(500 * res.height / res.width);
              oldwidth[j] = res.width
              oldheight[j] = res.height
              console.log('第', j, '高', toheight)
              console.log('第', j, '宽', towidth)
              console.log('toheight', toheight)
              j++
              that.setData({
                imginfo: ++imgInfo
              })
              if (j == photo.tempFilePaths.length) {
                console.log('tmpDataArr ', tmpDataArr)
                tempFilePathsShow = photo.tempFilePaths //这个是选择后返回的图片列表
                console.log('tempFilePathsShow', tempFilePathsShow, 'towidth', towidth, 'toheight', toheight)
                console.log('toheight', toheight)
                that.getCanvasImg(0, 0, tempFilePathsShow, oldwidth, oldheight, towidth, toheight); //进行压缩
                that.setData({
                  tempfilepaths: tempFilePathsShow
                })
              }
              wx.getImageInfo({
                src: photo.tempFilePaths[j],
                success: function(res) { //3
                  console.log('res', res)
                  console.log('第', j, '高', res.height)
                  console.log('第', j, '宽', res.width)
                  towidth[j] = 500; //按比例压缩
                  toheight[j] = Math.trunc(500 * res.height / res.width);
                  oldwidth[j] = res.width
                  oldheight[j] = res.height
                  console.log('第', j, '高', toheight)
                  console.log('第', j, '宽', towidth)
                  console.log('toheight', toheight)
                  j++
                  that.setData({
                    imginfo: ++imgInfo
                  })
                  if (j == photo.tempFilePaths.length) {
                    console.log('tmpDataArr ', tmpDataArr)
                    tempFilePathsShow = photo.tempFilePaths //这个是选择后返回的图片列表
                    console.log('tempFilePathsShow', tempFilePathsShow, 'towidth', towidth, 'toheight', toheight)
                    console.log('toheight', toheight)
                    that.getCanvasImg(0, 0, tempFilePathsShow, oldwidth, oldheight, towidth, toheight); //进行压缩
                    that.setData({
                      tempfilepaths: tempFilePathsShow
                    })
                  }
                  wx.getImageInfo({
                    src: photo.tempFilePaths[j],
                    success: function(res) { //4
                      console.log('res', res)
                      console.log('第', j, '高', res.height)
                      console.log('第', j, '宽', res.width)
                      towidth[j] = 500; //按比例压缩
                      toheight[j] = Math.trunc(500 * res.height / res.width);
                      oldwidth[j] = res.width
                      oldheight[j] = res.height
                      console.log('第', j, '高', toheight)
                      console.log('第', j, '宽', towidth)
                      console.log('toheight', toheight)
                      j++
                      that.setData({
                        imginfo: ++imgInfo
                      })
                      if (j == photo.tempFilePaths.length) {
                        console.log('tmpDataArr ', tmpDataArr)
                        tempFilePathsShow = photo.tempFilePaths //这个是选择后返回的图片列表
                        console.log('tempFilePathsShow', tempFilePathsShow, 'towidth', towidth, 'toheight', toheight)
                        console.log('toheight', toheight)
                        that.getCanvasImg(0, 0, tempFilePathsShow, oldwidth, oldheight, towidth, toheight); //进行压缩
                        that.setData({
                          tempfilepaths: tempFilePathsShow
                        })
                      }
                    }
                  })
                }
              })
            }
          })
        }
      })



      // for (var i = 0; i < photo.tempFilePaths.length;) {
      //   if (j == i) {

      //     i++
      //   }
      // }
    },
    fail: function(res) {},
    complete: function(res) {
      if (res.tempFilePaths == undefined) {
        wx.navigateBack({
          delta: 1,
        })
      }
    },
  })
}


Page({
  data: {
    imageCount: 0, //图片数
    titleCount: 0, //标题字数
    contentCount: 0, //标题字数
    title: '', //标题内容
    moneyNum: null,
    ifnewarray: ['全新', '99新', '95新', '9成新', '8成新', '7成新', '5成新', '能用', '不能用'],
    ifnewindex: 0,
    classification1array: ['数码3C', '生活洗护', '学习文创', '专业器具', '其他服务'],
    classification1index: 0,
    multiArray: [
      ['电脑相关', '手机相关', '数码产品'],
      ['鼠标', '键盘', '显示器', '其他']
    ], //多列选择器
    multiIndex: [0, 0], //多列选择器
    addinggoodsnow: false,
    addinggoodssuccess: false, //不显示商品上传成功按钮
    overimgamount: 0 //初始上传成功图片数为0
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  onLoad: function() {
    console.log('imgurl.length', imgurl.length)
    var that = this
    id = wx.getStorageSync('id')
    session = wx.getStorageSync('session')
    infernal(that)
  },


  //压缩并获取图片，这里用了递归的方法来解决canvas的draw方法延时的问题
  getCanvasImg: function(index, failNum, tempFilePaths, ow, oh, tw, th) {
    var that = this;
    if (index < tempFilePaths.length) {
      var ctx = wx.createCanvasContext('attendCanvasId');
      console.log('第', index, '次:', tempFilePaths[index], 0, 0, ow[index], oh[index], 0, 0, tw[index], th[index])
      that.setData({
        canvas_w: ow[index],
        canvas_h: oh[index]
      })
      console.log('后第', index, '次:', tempFilePaths[index], 0, 0, ow[index], oh[index], 0, 0, tw[index], this.data.canvas_h)

      ctx.drawImage(tempFilePaths[index], 0, 0, ow[index], oh[index], 0, 0, ow[index], oh[index]);
      // setTimeout(function() {}, 1500)
      ctx.draw(false, setTimeout(function() {
        console.log('接口前', index, ow[index], oh[index], tw[index], th[index])
        wx.canvasToTempFilePath({
          width: ow[index],
          height: oh[index],
          destWidth: tw[index],
          destHeight: th[index],
          canvasId: 'attendCanvasId',
          fileType: "jpg",
          success: function success(res) {
            console.log('测试图片中！', res.tempFilePath, tw[index], th[index])
            that.setData({
              testimg: res.tempFilePath
            })
            index = index + 1; //上传成功的数量，上传成功则加1
            that.uploadCanvasImg(res.tempFilePath);
            that.getCanvasImg(index, failNum, tempFilePaths, ow, oh, tw, th);
          },
          fail: function(e) {
            failNum += 1; //失败数量，可以用来提示用户
            that.getCanvasImg(index, failNum, tempFilePaths, ow, oh, tw, th);
          }
        });
      }, 1000));
    }
  },
  //上传图片
  uploadCanvasImg: function(canvasImg) {
    var that = this;
    var tempImg = canvasImg;
    wx.uploadFile({
      url: 'https://theonlyobserver.cn/image/image.php', //文件服务器的地址
      filePath: tempImg,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      formData: {
        i: app.globalData.id, // 用户id,
        p: app.globalData.session, // "登陆凭证",
        m: "object" // "user或者时object"
      },
      name: 'd',
      success: function(res) {
        console.log(JSON.parse(res.data).data)
        var json2map = JSON.parse(res.data).data;
        imgViewList.push(json2map[0]);
        console.log(' imgViewList', imgViewList)
        k++
      }
    })
  },

  rechooseImages: function() {
    var that = this
    if (k != tempFilePathsShow.length) {
      wx.showToast({
        title: '图片压缩上传中' + k + '/' + tempFilePathsShow.length + '请稍候',
        icon: 'none',
        duration: 2000,
        mask: true
      })
    } else {
      k = 0
      //重新选择图片时，所有有关图片的参数初始化
      infernal(that)
    }

  },

  //标题字数统计
  handleTitleInput: function(e) {
    title = e.detail.value;
    // console.log(value.length);
    this.setData({
      titleCount: title.length
    })
  },

  //正文字数统计
  handleContentInput: function(e) {
    content = e.detail.value;
    // console.log(value.length);
    this.setData({
      contentCount: content.length
    })
  },

  //输入价格时触发
  inputedit(event) {
    this.setData({
      //执行价格格式限制函数
      moneyNum: money(event.detail.value) //money匹配金额输入规则，返回输入值
    });
    price = Number(money(event.detail.value));
  },

  //新旧选择器触发
  ifnewBindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    console.log('picker发送选择改变，携带值为', this.data.ifnewarray[e.detail.value])
    this.setData({
      ifnewindex: e.detail.value
    })
    switch (e.detail.value) {
      case '0':
        {
          ifnewpercent = 100;
          break;
        }
      case '1':
        {
          ifnewpercent = 99;
          break;
        }
      case '2':
        {
          ifnewpercent = 95;
          break;
        }
      case '3':
        {
          ifnewpercent = 90;
          break;
        }
      case '4':
        {
          ifnewpercent = 80;
          break;
        }
      case "5":
        {
          ifnewpercent = 70;
          break;
        }
      case '6':
        {
          ifnewpercent = 50;
          break;
        }
      case '7':
        {
          ifnewpercent = 40;
          break;
        }
      case '8':
        {
          ifnewpercent = 10;
          break;
        }
    }

  },

  //主分类选择器触发
  classification1BindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    console.log('picker发送选择改变，携带值为', this.data.classification1array[e.detail.value])
    classification1 = Number(e.detail.value) + 1
    this.setData({
      classification1index: e.detail.value
    })
    console.log("所选分类为", classification1)
    switch (classification1) {
      case 1:
        {
          console.log("执行数码3C分类")
          multiarray = [
            ['电脑相关', '手机相关', '数码产品'],
            ['鼠标', '键盘', '显示器', '其他']
          ]
          this.setData({
            multiArray: multiarray
          })
          break;
        }
      case 2:
        {
          console.log("执行生活洗护分类")
          multiarray = [
            ['服饰相关', '化妆洗护', '寝室用品', '运动相关', '食品饮品'],
            ['女装', '男装', '女鞋', '男鞋', '帽子/饰品', '其他']
          ]
          this.setData({
            multiArray: multiarray
          })
          break;
        }
      case 3:
        {
          console.log("执行学习文创分类")
          multiarray = [
            ['书籍资料', '文具相关'],
            ['四六级资料', '考研资料', '外语资料', '通用课本', '课外书籍', '其他']
          ]
          this.setData({
            multiArray: multiarray
          })
          break;
        }
      case 4:
        {
          console.log("执行专业器具分类")
          multiarray = [
            ['艺术设计', '服装设计', '机械工程', '轻工化学', '生物工程', '纺织材料', '信息科学', '食品', '管理', '外国语'],
            ['其他']
          ]
          this.setData({
            multiArray: multiarray
          })
          break;
        }
      case 5:
        {
          console.log("执行其他分类")
          multiarray = [
            ['虚拟商品', '招聘兼职', '项目/竞赛合伙'],
            ['其他']
          ]
          this.setData({
            multiArray: multiarray
          })
          break;
        }
    }

  },
  //副分类选择器触发
  bindMultiPickerChange: function(e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
    classification2 = e.detail.value[0] + 1
    classification3 = e.detail.value[1] + 1
    console.log("筛选结果变更，最终传递的值可以是", this.data.multiArray[0][e.detail.value[0]], this.data.multiArray[1][e.detail.value[1]]) //这个数组我都能写明白我是真nb，但是其实我也看不太懂
    console.log(classification1)
  },
  //副分类选择器列变动触发
  bindMultiPickerColumnChange: function(e) {
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    switch (classification1) {
      case 1:
        {
          console.log("执行数码3C下详细分类")

          //////////////////////////////////////////////////////////////////////////
          switch (e.detail.column) {
            case 0:
              switch (data.multiIndex[0]) {

                case 0:
                  data.multiArray[1] = ['鼠标', '键盘', '显示器', '其他'];
                  break;
                case 1:
                  data.multiArray[1] = ['手机', '其他'];
                  break;
                case 2:
                  data.multiArray[1] = ['耳机相关', '单反相关', '其他'];
                  break;
              }
              data.multiIndex[1] = 0;
              break;
              console.log(data.multiIndex);
              break;
          }
          /////////////////////////////////////////////////////////////////
          break;
        }
      case 2:
        {
          console.log("执行生活洗护下详细分类")

          //////////////////////////////////////////////////////////////////////////
          switch (e.detail.column) {
            case 0:
              switch (data.multiIndex[0]) {

                case 0:
                  data.multiArray[1] = ['女装', '男装', '女鞋', '男鞋', '帽子/饰品', '其他'];
                  break;
                case 1:
                  data.multiArray[1] = ['化妆品', '洗护品', '其他'];
                  break;
                case 2:
                  data.multiArray[1] = ['桌椅', '宿舍神器', '其他'];
                  break;
                case 3:
                  data.multiArray[1] = ['运动户外', '健身器材', '其他'];
                  break;
                case 4:
                  data.multiArray[1] = ['方便食品', '饮料酒水', '其他'];
                  break;
              }
              data.multiIndex[1] = 0;
              break;
              console.log(data.multiIndex);
              break;
          }
          /////////////////////////////////////////////////////////////////



          break;
        }
      case 3:
        {
          console.log("执行学习文创下详细分类")


          //////////////////////////////////////////////////////////////////////////
          switch (e.detail.column) {
            case 0:
              switch (data.multiIndex[0]) {

                case 0:
                  data.multiArray[1] = ['四六级资料', '考研资料', '外语资料', '通用课本', '课外书籍', '其他'];
                  break;
                case 1:
                  data.multiArray[1] = ['纸/本', '笔袋里的东西', '其他'];
                  break;
              }
              data.multiIndex[1] = 0;
              break;
              console.log(data.multiIndex);
              break;
          }
          /////////////////////////////////////////////////////////////////



          break;
        }
      case 4:
        {
          console.log("执行专业器具下详细分类")
          //////////////////////////////////////////////////////////////////////////
          switch (e.detail.column) {
            case 0:
              switch (data.multiIndex[0]) {
                case 0:
                  data.multiArray[1] = ['其他'];
                  break;
                case 1:
                  data.multiArray[1] = ['其他'];
                  break;
                case 2:
                  data.multiArray[1] = ['其他'];
                  break;
                case 3:
                  data.multiArray[1] = ['其他'];
                  break;
                case 4:
                  data.multiArray[1] = ['其他'];
                  break;
                case 5:
                  data.multiArray[1] = ['其他'];
                  break;
                case 6:
                  data.multiArray[1] = ['其他'];
                  break;
                case 7:
                  data.multiArray[1] = ['其他'];
                  break;
                case 8:
                  data.multiArray[1] = ['其他'];
                  break;
                case 9:
                  data.multiArray[1] = ['其他'];
                  break;
              }
              data.multiIndex[1] = 0;
              break;
              console.log(data.multiIndex);
              break;
          }
          /////////////////////////////////////////////////////////////////
          break;
        }
      case 5:
        {
          console.log("执行其他下详细分类")
          //////////////////////////////////////////////////////////////////////////
          switch (e.detail.column) {
            case 0:
              switch (data.multiIndex[0]) {
                case 0:
                  data.multiArray[1] = ['其他'];
                  break;
                case 1:
                  data.multiArray[1] = ['其他'];
                  break;
                case 2:
                  data.multiArray[1] = ['其他'];
                  break;

              }
              data.multiIndex[1] = 0;
              break;
              console.log(data.multiIndex);
              break;
          }
          /////////////////////////////////////////////////////////////////
          break;
        }
    }
    this.setData(data);
  },
  //上传商品按钮触发
  addGoods: function(e) {
    var that = this
    console.log('k', k)
    if (k != tempFilePathsShow.length) {
      wx.showToast({
        title: '图片压缩上传中' + k + '/' + tempFilePathsShow.length + '请稍候',
        icon: 'none',
        duration: 2000,
        mask: true
      })
    } else {

      classification23 = convert(classification2, classification3)
      if (title && content && imgViewList && price && ifnewpercent && classification1 && classification23) {
        console.log('信息已填写完整')
        this.setData({
          addinggoodsnow: true
        })

        console.log('图片数量', tempFilePathsShow.length)
        console.log('id,session为', id, session)
        console.log('title为', title)
        console.log('content为', content)
        console.log('price为', price)
        console.log('ifnewpercent为', ifnewpercent)
        console.log('1，2，3级分类为', classification1, classification2, classification3)
        console.log('合并2，3级分类为', classification23)

        wx.request({
          url: 'https://theonlyobserver.cn/object/updataobject.php',
          data: {
            i: id,
            p: session,
            d: JSON.stringify({
              "stat_a": classification1, //大分类代码
              "stat_b": classification23, //小分类代码
              "title": title, //商品标题（限80字）
              "price": price, //价格（可以带小数点）
              "new": ifnewpercent, //新旧程度，百分数
              "intro": {
                "content": content,
                "imgurl": imgViewList
              }
            })
          },
          success: function() {
            //商品上传成功时显示商品上传成功按钮
            that.setData({
              addinggoodssuccess: true
            })

            k = 0 //上传成功的图片计数重新归0
          },
          complete: function(res) {
            console.log(res)
          }
        })

      } else {
        wx.showToast({
          title: '信息未填写完整',
          icon: 'none',
          duration: 1500,
          mask: false
        })
      }
    }

  },
  onUnload: function() {
    k = 0 //上传成功的图片计数重新归0
    tempFilePathsShow = []
    imgurl = []
    imgViewList = []
    towidth = []
    toheight = []
    oldwidth = []
    oldheight = []
  }
})